# COL106-A3-testCases-generator

Clone the repo and place all the files related to the assignmet in this directory. Compile and run the tester.cpp.
also if in windows you may need to replace python3 with py in the tester.cpp file.


Sugegstion:
Try replacing your hash function with someting bad to get a lot of hash collission for testing.
